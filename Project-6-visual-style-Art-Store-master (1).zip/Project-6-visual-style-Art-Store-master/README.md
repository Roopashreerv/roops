# Project-6-visual-style-Art-Store
 This project builds on the art store but purposefully leaves you having to dig a little deeper into CSS.  
